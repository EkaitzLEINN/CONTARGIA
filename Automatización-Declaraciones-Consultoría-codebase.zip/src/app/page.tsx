"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { useSession } from "@/lib/auth-client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { FileText, Users, FileBarChart, TrendingUp, CheckCircle, Loader2 } from "lucide-react";
import Link from "next/link";

export default function Home() {
  const router = useRouter();
  const { data: session, isPending } = useSession();

  useEffect(() => {
    if (!isPending && session?.user) {
      router.push("/dashboard");
    }
  }, [session, isPending, router]);

  if (isPending) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (session?.user) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
      {/* Header */}
      <header className="border-b bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <div className="bg-primary text-primary-foreground p-2 rounded-lg">
              <FileText className="h-6 w-6" />
            </div>
            <div>
              <h1 className="font-bold text-xl">Declaraciones Trimestrales</h1>
              <p className="text-xs text-muted-foreground">Sistema de Automatización</p>
            </div>
          </div>
          <div className="flex gap-2">
            <Link href="/sign-in">
              <Button variant="ghost">Iniciar Sesión</Button>
            </Link>
            <Link href="/sign-up">
              <Button>Registrarse</Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="container mx-auto px-4 py-20 text-center">
        <div className="max-w-3xl mx-auto space-y-6">
          <div className="inline-block">
            <div className="bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-medium">
              🚀 Solución para Consultorías
            </div>
          </div>
          <h1 className="text-5xl md:text-6xl font-bold tracking-tight">
            Automatiza tus
            <span className="text-primary"> Declaraciones Trimestrales</span>
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Gestiona clientes, procesa facturas y genera reportes trimestrales de forma
            automática y eficiente. Diseñado específicamente para consultorías fiscales.
          </p>
          <div className="flex gap-4 justify-center pt-4">
            <Link href="/sign-up">
              <Button size="lg" className="text-lg px-8">
                Comenzar Gratis
              </Button>
            </Link>
            <Link href="/sign-in">
              <Button size="lg" variant="outline" className="text-lg px-8">
                Ver Demo
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="container mx-auto px-4 py-20">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">Características Principales</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Todo lo que necesitas para automatizar tus declaraciones trimestrales en una
            sola plataforma
          </p>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            {
              icon: Users,
              title: "Gestión de Clientes",
              description: "Administra toda la información de tus clientes en un solo lugar",
              color: "text-blue-600",
              bgColor: "bg-blue-50 dark:bg-blue-950",
            },
            {
              icon: FileBarChart,
              title: "Reportes Trimestrales",
              description: "Crea y gestiona reportes trimestrales por cliente y periodo",
              color: "text-green-600",
              bgColor: "bg-green-50 dark:bg-green-950",
            },
            {
              icon: FileText,
              title: "Procesamiento de Facturas",
              description: "Registra y organiza facturas con todos sus detalles fiscales",
              color: "text-purple-600",
              bgColor: "bg-purple-50 dark:bg-purple-950",
            },
            {
              icon: TrendingUp,
              title: "Exportación a Excel",
              description: "Exporta tus datos a Excel con un solo clic para análisis",
              color: "text-orange-600",
              bgColor: "bg-orange-50 dark:bg-orange-950",
            },
          ].map((feature) => (
            <Card key={feature.title} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className={`${feature.bgColor} w-12 h-12 rounded-lg flex items-center justify-center mb-4`}>
                  <feature.icon className={`h-6 w-6 ${feature.color}`} />
                </div>
                <CardTitle className="text-lg">{feature.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>{feature.description}</CardDescription>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Benefits Section */}
      <section className="bg-white dark:bg-gray-800 py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-3xl font-bold text-center mb-12">
              ¿Por qué elegir nuestro sistema?
            </h2>
            <div className="space-y-6">
              {[
                "Ahorra tiempo automatizando tareas repetitivas",
                "Reduce errores en el procesamiento de facturas",
                "Mantén toda la información centralizada y organizada",
                "Genera reportes profesionales en minutos",
                "Cumple con los requisitos fiscales mexicanos",
                "Interfaz intuitiva y fácil de usar",
              ].map((benefit) => (
                <div key={benefit} className="flex items-start gap-3">
                  <CheckCircle className="h-6 w-6 text-green-600 flex-shrink-0 mt-0.5" />
                  <p className="text-lg">{benefit}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="container mx-auto px-4 py-20">
        <Card className="bg-gradient-to-br from-primary to-primary/80 text-primary-foreground border-0">
          <CardContent className="p-12 text-center space-y-6">
            <h2 className="text-3xl md:text-4xl font-bold">
              ¿Listo para optimizar tu trabajo?
            </h2>
            <p className="text-lg opacity-90 max-w-2xl mx-auto">
              Únete a las consultorías que ya están automatizando sus declaraciones
              trimestrales
            </p>
            <div className="pt-4">
              <Link href="/sign-up">
                <Button size="lg" variant="secondary" className="text-lg px-8">
                  Comenzar Ahora
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </section>

      {/* Footer */}
      <footer className="border-t bg-white dark:bg-gray-900 py-8">
        <div className="container mx-auto px-4 text-center text-muted-foreground">
          <p>© 2024 Declaraciones Trimestrales. Sistema de Automatización para Consultorías.</p>
        </div>
      </footer>
    </div>
  );
}