import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { invoices, quarterlyReports } from '@/db/schema';
import { eq, like, and, or, desc, asc } from 'drizzle-orm';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');
    
    // Single invoice by ID
    if (id) {
      if (!id || isNaN(parseInt(id))) {
        return NextResponse.json({
          error: "Valid ID is required",
          code: "INVALID_ID"
        }, { status: 400 });
      }

      const invoice = await db.select()
        .from(invoices)
        .where(eq(invoices.id, parseInt(id)))
        .limit(1);

      if (invoice.length === 0) {
        return NextResponse.json({ error: 'Invoice not found' }, { status: 404 });
      }

      return NextResponse.json(invoice[0]);
    }

    // List invoices with pagination and search
    const limit = Math.min(parseInt(searchParams.get('limit') || '10'), 100);
    const offset = parseInt(searchParams.get('offset') || '0');
    const search = searchParams.get('search');
    const sortField = searchParams.get('sort') || 'createdAt';
    const sortOrder = searchParams.get('order') || 'desc';

    let query = db.select().from(invoices);

    if (search) {
      query = query.where(
        or(
          like(invoices.invoiceNumber, `%${search}%`),
          like(invoices.supplierName, `%${search}%`),
          like(invoices.concept, `%${search}%`)
        )
      );
    }

    // Apply sorting
    const orderBy = sortOrder === 'asc' ? asc : desc;
    if (sortField === 'invoiceDate') {
      query = query.orderBy(orderBy(invoices.invoiceDate));
    } else if (sortField === 'supplierName') {
      query = query.orderBy(orderBy(invoices.supplierName));
    } else if (sortField === 'total') {
      query = query.orderBy(orderBy(invoices.total));
    } else {
      query = query.orderBy(orderBy(invoices.createdAt));
    }

    const results = await query.limit(limit).offset(offset);
    return NextResponse.json(results);

  } catch (error) {
    console.error('GET error:', error);
    return NextResponse.json({
      error: 'Internal server error: ' + error
    }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const requestBody = await request.json();
    const {
      reportId,
      invoiceNumber,
      invoiceDate,
      supplierName,
      supplierRfc,
      subtotal,
      tax,
      total,
      concept,
      fileUrl
    } = requestBody;

    // Validate required fields
    if (!reportId) {
      return NextResponse.json({
        error: "Report ID is required",
        code: "MISSING_REPORT_ID"
      }, { status: 400 });
    }

    if (!invoiceNumber) {
      return NextResponse.json({
        error: "Invoice number is required",
        code: "MISSING_INVOICE_NUMBER"
      }, { status: 400 });
    }

    if (!invoiceDate) {
      return NextResponse.json({
        error: "Invoice date is required",
        code: "MISSING_INVOICE_DATE"
      }, { status: 400 });
    }

    if (!supplierName) {
      return NextResponse.json({
        error: "Supplier name is required",
        code: "MISSING_SUPPLIER_NAME"
      }, { status: 400 });
    }

    if (subtotal === undefined || subtotal === null) {
      return NextResponse.json({
        error: "Subtotal is required",
        code: "MISSING_SUBTOTAL"
      }, { status: 400 });
    }

    if (tax === undefined || tax === null) {
      return NextResponse.json({
        error: "Tax is required",
        code: "MISSING_TAX"
      }, { status: 400 });
    }

    if (total === undefined || total === null) {
      return NextResponse.json({
        error: "Total is required",
        code: "MISSING_TOTAL"
      }, { status: 400 });
    }

    // Validate reportId exists
    const reportExists = await db.select()
      .from(quarterlyReports)
      .where(eq(quarterlyReports.id, parseInt(reportId)))
      .limit(1);

    if (reportExists.length === 0) {
      return NextResponse.json({
        error: "Referenced report does not exist",
        code: "INVALID_REPORT_ID"
      }, { status: 400 });
    }

    // Validate numeric fields
    if (isNaN(parseFloat(subtotal))) {
      return NextResponse.json({
        error: "Subtotal must be a valid number",
        code: "INVALID_SUBTOTAL"
      }, { status: 400 });
    }

    if (isNaN(parseFloat(tax))) {
      return NextResponse.json({
        error: "Tax must be a valid number",
        code: "INVALID_TAX"
      }, { status: 400 });
    }

    if (isNaN(parseFloat(total))) {
      return NextResponse.json({
        error: "Total must be a valid number",
        code: "INVALID_TOTAL"
      }, { status: 400 });
    }

    // Create new invoice
    const newInvoice = await db.insert(invoices)
      .values({
        reportId: parseInt(reportId),
        invoiceNumber: invoiceNumber.trim(),
        invoiceDate: invoiceDate,
        supplierName: supplierName.trim(),
        supplierRfc: supplierRfc ? supplierRfc.trim() : null,
        subtotal: parseFloat(subtotal),
        tax: parseFloat(tax),
        total: parseFloat(total),
        concept: concept ? concept.trim() : null,
        fileUrl: fileUrl ? fileUrl.trim() : null,
        createdAt: new Date().toISOString()
      })
      .returning();

    return NextResponse.json(newInvoice[0], { status: 201 });

  } catch (error) {
    console.error('POST error:', error);
    return NextResponse.json({
      error: 'Internal server error: ' + error
    }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (!id || isNaN(parseInt(id))) {
      return NextResponse.json({
        error: "Valid ID is required",
        code: "INVALID_ID"
      }, { status: 400 });
    }

    const requestBody = await request.json();
    const {
      reportId,
      invoiceNumber,
      invoiceDate,
      supplierName,
      supplierRfc,
      subtotal,
      tax,
      total,
      concept,
      fileUrl
    } = requestBody;

    // Check if invoice exists
    const existingInvoice = await db.select()
      .from(invoices)
      .where(eq(invoices.id, parseInt(id)))
      .limit(1);

    if (existingInvoice.length === 0) {
      return NextResponse.json({ error: 'Invoice not found' }, { status: 404 });
    }

    // Validate fields if provided
    if (reportId !== undefined) {
      const reportExists = await db.select()
        .from(quarterlyReports)
        .where(eq(quarterlyReports.id, parseInt(reportId)))
        .limit(1);

      if (reportExists.length === 0) {
        return NextResponse.json({
          error: "Referenced report does not exist",
          code: "INVALID_REPORT_ID"
        }, { status: 400 });
      }
    }

    if (subtotal !== undefined && isNaN(parseFloat(subtotal))) {
      return NextResponse.json({
        error: "Subtotal must be a valid number",
        code: "INVALID_SUBTOTAL"
      }, { status: 400 });
    }

    if (tax !== undefined && isNaN(parseFloat(tax))) {
      return NextResponse.json({
        error: "Tax must be a valid number",
        code: "INVALID_TAX"
      }, { status: 400 });
    }

    if (total !== undefined && isNaN(parseFloat(total))) {
      return NextResponse.json({
        error: "Total must be a valid number",
        code: "INVALID_TOTAL"
      }, { status: 400 });
    }

    // Prepare update data
    const updateData: any = {
      updatedAt: new Date().toISOString()
    };

    if (reportId !== undefined) updateData.reportId = parseInt(reportId);
    if (invoiceNumber !== undefined) updateData.invoiceNumber = invoiceNumber.trim();
    if (invoiceDate !== undefined) updateData.invoiceDate = invoiceDate;
    if (supplierName !== undefined) updateData.supplierName = supplierName.trim();
    if (supplierRfc !== undefined) updateData.supplierRfc = supplierRfc ? supplierRfc.trim() : null;
    if (subtotal !== undefined) updateData.subtotal = parseFloat(subtotal);
    if (tax !== undefined) updateData.tax = parseFloat(tax);
    if (total !== undefined) updateData.total = parseFloat(total);
    if (concept !== undefined) updateData.concept = concept ? concept.trim() : null;
    if (fileUrl !== undefined) updateData.fileUrl = fileUrl ? fileUrl.trim() : null;

    const updated = await db.update(invoices)
      .set(updateData)
      .where(eq(invoices.id, parseInt(id)))
      .returning();

    return NextResponse.json(updated[0]);

  } catch (error) {
    console.error('PUT error:', error);
    return NextResponse.json({
      error: 'Internal server error: ' + error
    }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (!id || isNaN(parseInt(id))) {
      return NextResponse.json({
        error: "Valid ID is required",
        code: "INVALID_ID"
      }, { status: 400 });
    }

    // Check if invoice exists
    const existingInvoice = await db.select()
      .from(invoices)
      .where(eq(invoices.id, parseInt(id)))
      .limit(1);

    if (existingInvoice.length === 0) {
      return NextResponse.json({ error: 'Invoice not found' }, { status: 404 });
    }

    const deleted = await db.delete(invoices)
      .where(eq(invoices.id, parseInt(id)))
      .returning();

    return NextResponse.json({
      message: 'Invoice deleted successfully',
      deletedInvoice: deleted[0]
    });

  } catch (error) {
    console.error('DELETE error:', error);
    return NextResponse.json({
      error: 'Internal server error: ' + error
    }, { status: 500 });
  }
}