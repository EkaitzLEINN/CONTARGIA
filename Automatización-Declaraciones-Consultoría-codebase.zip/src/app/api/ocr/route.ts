import { NextResponse } from "next/server";
import pdfParse from "pdf-parse";

function parseSpanishInvoice(text: string) {
  const cleaned = text.replace(/\r/g, "");

  // Número de factura
  const numMatch = cleaned.match(/(?:factura|nº\s*factura|num(?:ero)?)\s*[:#-]?\s*([A-Z0-9\/\-]{3,})/i);
  const invoiceNumber = numMatch?.[1]?.trim() || "";

  // Fecha (dd/mm/yyyy o yyyy-mm-dd)
  const dateMatch = cleaned.match(/(\b\d{2}[\/\-]\d{2}[\/\-]\d{4}\b|\b\d{4}-\d{2}-\d{2}\b)/);
  let invoiceDate = "";
  if (dateMatch) {
    const d = dateMatch[1];
    if (/^\d{2}[\/\-]\d{2}[\/\-]\d{4}$/.test(d)) {
      const [dd, mm, yyyy] = d.split(/[\/\-]/).map((p) => parseInt(p, 10));
      const iso = new Date(yyyy, mm - 1, dd).toISOString().slice(0, 10);
      invoiceDate = iso;
    } else {
      invoiceDate = new Date(d).toISOString().slice(0, 10);
    }
  }

  // Proveedor (heurística)
  const supplierMatch = cleaned.match(/(?:proveedor|emisor|empresa)[:\s]+(.+)/i);
  const supplierName = supplierMatch?.[1]?.split("\n")[0].trim() || "";

  // Identificador fiscal del proveedor (NIF/NIE/CIF)
  const taxIdRegex = /\b([ABCDEFGHJKLMNPQRSUVW]\d{7}[0-9A-J]|[XYZ]?\d{7,8}[A-Z])\b/gi;
  const taxIds = Array.from(cleaned.matchAll(taxIdRegex)).map((m) => m[1]);
  const supplierRfc = taxIds.length > 0 ? taxIds[0].toUpperCase() : null;

  // Subtotal, IVA, Total (aceptar coma o punto)
  const money = (s?: string) => {
    if (!s) return NaN;
    const norm = s.replace(/[.]/g, "").replace(",", ".");
    const n = parseFloat(norm);
    return isNaN(n) ? NaN : n;
  };

  const subtotalMatch = cleaned.match(/(?:base\s*imponible|subtotal)[:\s]*([0-9.,]+)/i);
  const taxMatch = cleaned.match(/(?:iva|impuesto\s*iva)[:\s]*([0-9.,]+)/i);
  const totalMatch = cleaned.match(/(?:total\s*(?:factura)?|importe\s*total)[:\s]*([0-9.,]+)/i);

  const subtotal = money(subtotalMatch?.[1]);
  const tax = money(taxMatch?.[1]);
  let total = money(totalMatch?.[1]);

  if (isNaN(total) && !isNaN(subtotal) && !isNaN(tax)) {
    total = subtotal + tax;
  }

  // Concepto
  const conceptMatch = cleaned.match(/(?:concepto|descripci[óo]n)[:\s]*([^\n]+)/i);
  const concept = conceptMatch?.[1]?.trim() || "";

  // Resumen breve
  const summaryParts: string[] = [];
  if (invoiceNumber) summaryParts.push(`Factura ${invoiceNumber}`);
  if (invoiceDate) summaryParts.push(`Fecha ${invoiceDate}`);
  if (supplierName) summaryParts.push(`Proveedor ${supplierName}`);
  if (!isNaN(total)) summaryParts.push(`Total ${total.toFixed(2)}€`);
  if (supplierRfc) summaryParts.push(`ID ${supplierRfc}`);
  const summary = summaryParts.join(" · ");

  return {
    invoiceNumber,
    invoiceDate,
    supplierName,
    supplierRfc,
    subtotal: isNaN(subtotal) ? null : subtotal,
    tax: isNaN(tax) ? null : tax,
    total: isNaN(total) ? null : total,
    concept,
    rawText: cleaned,
    summary,
  };
}

async function extractWithDeepSeek(text: string) {
  const apiKey = process.env.DEEPSEEK_API_KEY;
  if (!apiKey) {
    console.warn("DEEPSEEK_API_KEY not configured, falling back to regex");
    return null;
  }

  try {
    const response = await fetch("https://api.deepseek.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "deepseek-chat",
        messages: [
          {
            role: "system",
            content: "Eres un experto en extraer información de facturas españolas. Extrae SOLO los datos solicitados en formato JSON limpio sin markdown."
          },
          {
            role: "user",
            content: `Extrae la siguiente información de esta factura española y devuelve SOLO un objeto JSON válido (sin markdown, sin código):

{
  "invoiceNumber": "número de factura",
  "invoiceDate": "fecha en formato YYYY-MM-DD",
  "supplierName": "nombre del proveedor/empresa",
  "supplierRfc": "NIF/CIF/NIE del proveedor (formato: letra + dígitos + control)",
  "subtotal": número (base imponible),
  "tax": número (IVA),
  "total": número (total factura),
  "concept": "concepto o descripción breve",
  "summary": "resumen de 1-2 líneas con información clave"
}

Texto de la factura:
${text.substring(0, 4000)}`
          }
        ],
        temperature: 0.1,
        max_tokens: 800,
      }),
    });

    if (!response.ok) {
      console.error("DeepSeek API error:", response.status, await response.text());
      return null;
    }

    const data = await response.json();
    const content = data.choices?.[0]?.message?.content || "";
    
    // Remove markdown code blocks if present
    const cleaned = content.replace(/```json\n?/g, "").replace(/```\n?/g, "").trim();
    
    const parsed = JSON.parse(cleaned);
    return parsed;
  } catch (error) {
    console.error("DeepSeek extraction error:", error);
    return null;
  }
}

export async function POST(req: Request) {
  try {
    const form = await req.formData();
    const file = form.get("file");
    if (!file || !(file instanceof File)) {
      return NextResponse.json({ error: "No se recibió archivo" }, { status: 400 });
    }

    const filename = (file as File).name || "document";
    const type = (file as File).type || "";

    if (!(type.includes("pdf") || filename.toLowerCase().endsWith(".pdf"))) {
      return NextResponse.json(
        { error: "Formato no soportado. Sube un PDF." },
        { status: 415 }
      );
    }

    // Extract PDF text
    const buffer = Buffer.from(await (file as File).arrayBuffer());
    let pdfData;
    
    try {
      pdfData = await pdfParse(buffer);
    } catch (pdfError) {
      console.error("PDF parse error:", pdfError);
      return NextResponse.json(
        { error: "Error al leer el PDF. Asegúrate de que sea un PDF válido con texto." },
        { status: 422 }
      );
    }

    const extractedText = pdfData.text || "";
    
    if (!extractedText.trim()) {
      return NextResponse.json(
        { error: "El PDF no contiene texto extraíble. Puede ser un PDF escaneado." },
        { status: 422 }
      );
    }

    console.log("Extracted text length:", extractedText.length);
    console.log("First 200 chars:", extractedText.substring(0, 200));

    // Try DeepSeek first
    const deepseekResult = await extractWithDeepSeek(extractedText);
    
    if (deepseekResult) {
      console.log("Successfully extracted with DeepSeek");
      return NextResponse.json({ 
        success: true, 
        method: "deepseek", 
        data: deepseekResult 
      });
    }

    // Fallback to regex
    console.log("Falling back to regex extraction");
    const regexResult = parseSpanishInvoice(extractedText);
    return NextResponse.json({ 
      success: true, 
      method: "regex", 
      data: regexResult 
    });

  } catch (err: any) {
    console.error("OCR endpoint error:", err);
    return NextResponse.json(
      { error: err?.message || "Error procesando el documento" },
      { status: 500 }
    );
  }
}