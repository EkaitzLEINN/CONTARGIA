import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { clients } from '@/db/schema';
import { eq, like, and, or, desc, asc } from 'drizzle-orm';

// Spanish NIF/NIE/CIF validation function
function validateSpanishId(id: string): boolean {
  if (!id || typeof id !== 'string') return false;
  
  const cleanId = id.trim().toUpperCase();
  
  // CIF format: Letter + 7 digits + control (SIMPLIFIED - no checksum validation)
  const cifPattern = /^[ABCDEFGHJKLMNPQRSUVW]\d{7}[A-Z0-9]$/;
  // Standard Spanish NIF: 8 digits + 1 letter
  const nifPattern = /^[0-9]{8}[A-Z]$/;
  // Foreign resident NIE: 1 letter + 7 digits + 1 letter
  const niePattern = /^[XYZ][0-9]{7}[A-Z]$/;
  
  // Check CIF format (accept without checksum validation to avoid false rejections)
  if (cifPattern.test(cleanId)) {
    return true;
  }
  
  // Validate NIF checksum
  if (nifPattern.test(cleanId)) {
    const letters = 'TRWAGMYFPDXBNJZSQVHLCKE';
    const numbers = cleanId.substring(0, 8);
    const letter = cleanId.charAt(8);
    const expectedLetter = letters[parseInt(numbers) % 23];
    return letter === expectedLetter;
  }
  
  // Validate NIE checksum
  if (niePattern.test(cleanId)) {
    const letters = 'TRWAGMYFPDXBNJZSQVHLCKE';
    const firstLetter = cleanId.charAt(0);
    const numbers = cleanId.substring(1, 8);
    const letter = cleanId.charAt(8);
    
    // Convert first letter to number: X=0, Y=1, Z=2
    let prefix = '0';
    if (firstLetter === 'Y') prefix = '1';
    if (firstLetter === 'Z') prefix = '2';
    
    const fullNumber = prefix + numbers;
    const expectedLetter = letters[parseInt(fullNumber) % 23];
    return letter === expectedLetter;
  }
  
  return false;
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    // Single client by ID
    if (id) {
      if (!id || isNaN(parseInt(id))) {
        return NextResponse.json({ 
          error: "Valid ID is required",
          code: "INVALID_ID" 
        }, { status: 400 });
      }

      const client = await db.select()
        .from(clients)
        .where(eq(clients.id, parseInt(id)))
        .limit(1);

      if (client.length === 0) {
        return NextResponse.json({ error: 'Client not found' }, { status: 404 });
      }

      return NextResponse.json(client[0]);
    }

    // List clients with pagination and search
    const limit = Math.min(parseInt(searchParams.get('limit') || '10'), 100);
    const offset = parseInt(searchParams.get('offset') || '0');
    const search = searchParams.get('search');
    const sort = searchParams.get('sort') || 'createdAt';
    const order = searchParams.get('order') || 'desc';

    let query = db.select().from(clients);

    if (search) {
      const searchCondition = or(
        like(clients.name, `%${search}%`),
        like(clients.nif, `%${search}%`),
        like(clients.email, `%${search}%`)
      );
      query = query.where(searchCondition);
    }

    // Apply sorting
    const sortColumn = sort === 'name' ? clients.name : 
                      sort === 'nif' ? clients.nif :
                      sort === 'email' ? clients.email :
                      sort === 'updatedAt' ? clients.updatedAt :
                      clients.createdAt;

    if (order === 'asc') {
      query = query.orderBy(asc(sortColumn));
    } else {
      query = query.orderBy(desc(sortColumn));
    }

    const results = await query.limit(limit).offset(offset);

    return NextResponse.json(results);
  } catch (error) {
    console.error('GET error:', error);
    return NextResponse.json({ 
      error: 'Internal server error: ' + error 
    }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const requestBody = await request.json();
    const { name, nif, email, phone, address } = requestBody;

    // Validate required fields
    if (!name) {
      return NextResponse.json({ 
        error: "Name is required",
        code: "MISSING_REQUIRED_FIELD" 
      }, { status: 400 });
    }

    if (!nif) {
      return NextResponse.json({ 
        error: "NIF/NIE/CIF is required",
        code: "MISSING_REQUIRED_FIELD" 
      }, { status: 400 });
    }

    // Validate NIF/NIE/CIF format
    if (!validateSpanishId(nif)) {
      return NextResponse.json({ 
        error: "Invalid NIF/NIE/CIF format. Must be Spanish NIF (8 digits + letter), NIE (letter + 7 digits + letter), or CIF (letter + 7 digits + control)",
        code: "INVALID_ID_FORMAT" 
      }, { status: 400 });
    }

    // Check if NIF is unique
    const existingClient = await db.select()
      .from(clients)
      .where(eq(clients.nif, nif.trim().toUpperCase()))
      .limit(1);

    if (existingClient.length > 0) {
      return NextResponse.json({ 
        error: "NIF/NIE/CIF already exists",
        code: "ID_NOT_UNIQUE" 
      }, { status: 400 });
    }

    // Sanitize inputs
    const sanitizedData = {
      name: name.trim(),
      nif: nif.trim().toUpperCase(),
      email: email ? email.trim().toLowerCase() : null,
      phone: phone ? phone.trim() : null,
      address: address ? address.trim() : null,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    const newClient = await db.insert(clients)
      .values(sanitizedData)
      .returning();

    return NextResponse.json(newClient[0], { status: 201 });
  } catch (error) {
    console.error('POST error:', error);
    return NextResponse.json({ 
      error: 'Internal server error: ' + error 
    }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (!id || isNaN(parseInt(id))) {
      return NextResponse.json({ 
        error: "Valid ID is required",
        code: "INVALID_ID" 
      }, { status: 400 });
    }

    const requestBody = await request.json();
    const { name, nif, email, phone, address } = requestBody;

    // Security check: reject if userId provided in body
    if ('userId' in requestBody || 'user_id' in requestBody || 'authorId' in requestBody) {
      return NextResponse.json({ 
        error: "User ID cannot be provided in request body",
        code: "USER_ID_NOT_ALLOWED" 
      }, { status: 400 });
    }

    // Check if client exists
    const existingClient = await db.select()
      .from(clients)
      .where(eq(clients.id, parseInt(id)))
      .limit(1);

    if (existingClient.length === 0) {
      return NextResponse.json({ error: 'Client not found' }, { status: 404 });
    }

    // If NIF is being updated, validate format and check uniqueness
    if (nif && nif.trim().toUpperCase() !== existingClient[0].nif) {
      if (!validateSpanishId(nif)) {
        return NextResponse.json({ 
          error: "Invalid NIF/NIE/CIF format. Must be Spanish NIF (8 digits + letter), NIE (letter + 7 digits + letter), or CIF (letter + 7 digits + control)",
          code: "INVALID_ID_FORMAT" 
        }, { status: 400 });
      }

      const nifExists = await db.select()
        .from(clients)
        .where(eq(clients.nif, nif.trim().toUpperCase()))
        .limit(1);

      if (nifExists.length > 0) {
        return NextResponse.json({ 
          error: "NIF/NIE/CIF already exists",
          code: "ID_NOT_UNIQUE" 
        }, { status: 400 });
      }
    }

    // Prepare update data
    const updates: any = {
      updatedAt: new Date().toISOString()
    };

    if (name !== undefined) updates.name = name.trim();
    if (nif !== undefined) updates.nif = nif.trim().toUpperCase();
    if (email !== undefined) updates.email = email ? email.trim().toLowerCase() : null;
    if (phone !== undefined) updates.phone = phone ? phone.trim() : null;
    if (address !== undefined) updates.address = address ? address.trim() : null;

    const updatedClient = await db.update(clients)
      .set(updates)
      .where(eq(clients.id, parseInt(id)))
      .returning();

    if (updatedClient.length === 0) {
      return NextResponse.json({ error: 'Client not found' }, { status: 404 });
    }

    return NextResponse.json(updatedClient[0]);
  } catch (error) {
    console.error('PUT error:', error);
    return NextResponse.json({ 
      error: 'Internal server error: ' + error 
    }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (!id || isNaN(parseInt(id))) {
      return NextResponse.json({ 
        error: "Valid ID is required",
        code: "INVALID_ID" 
      }, { status: 400 });
    }

    // Check if client exists
    const existingClient = await db.select()
      .from(clients)
      .where(eq(clients.id, parseInt(id)))
      .limit(1);

    if (existingClient.length === 0) {
      return NextResponse.json({ error: 'Client not found' }, { status: 404 });
    }

    const deletedClient = await db.delete(clients)
      .where(eq(clients.id, parseInt(id)))
      .returning();

    if (deletedClient.length === 0) {
      return NextResponse.json({ error: 'Client not found' }, { status: 404 });
    }

    return NextResponse.json({
      message: 'Client deleted successfully',
      deletedClient: deletedClient[0]
    });
  } catch (error) {
    console.error('DELETE error:', error);
    return NextResponse.json({ 
      error: 'Internal server error: ' + error 
    }, { status: 500 });
  }
}