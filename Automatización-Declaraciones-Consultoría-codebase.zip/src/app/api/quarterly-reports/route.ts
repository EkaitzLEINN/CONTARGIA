import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { quarterlyReports, clients } from '@/db/schema';
import { eq, like, and, or, desc, asc } from 'drizzle-orm';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');
    
    if (id) {
      if (!id || isNaN(parseInt(id))) {
        return NextResponse.json({ 
          error: "Valid ID is required",
          code: "INVALID_ID" 
        }, { status: 400 });
      }

      const record = await db.select()
        .from(quarterlyReports)
        .where(eq(quarterlyReports.id, parseInt(id)))
        .limit(1);

      if (record.length === 0) {
        return NextResponse.json({ error: 'Quarterly report not found' }, { status: 404 });
      }

      return NextResponse.json(record[0]);
    }

    const limit = Math.min(parseInt(searchParams.get('limit') || '10'), 100);
    const offset = parseInt(searchParams.get('offset') || '0');
    const search = searchParams.get('search');
    const clientId = searchParams.get('client_id');
    const year = searchParams.get('year');
    const quarter = searchParams.get('quarter');
    const status = searchParams.get('status');
    const sort = searchParams.get('sort') || 'createdAt';
    const order = searchParams.get('order') || 'desc';

    let query = db.select().from(quarterlyReports);

    const conditions = [];

    if (clientId && !isNaN(parseInt(clientId))) {
      conditions.push(eq(quarterlyReports.clientId, parseInt(clientId)));
    }

    if (year && !isNaN(parseInt(year))) {
      conditions.push(eq(quarterlyReports.year, parseInt(year)));
    }

    if (quarter && !isNaN(parseInt(quarter))) {
      conditions.push(eq(quarterlyReports.quarter, parseInt(quarter)));
    }

    if (status) {
      conditions.push(eq(quarterlyReports.status, status));
    }

    if (search) {
      const searchCondition = or(
        like(quarterlyReports.status, `%${search}%`)
      );
      conditions.push(searchCondition);
    }

    if (conditions.length > 0) {
      query = query.where(and(...conditions));
    }

    if (sort === 'year') {
      query = order === 'asc' ? query.orderBy(asc(quarterlyReports.year)) : query.orderBy(desc(quarterlyReports.year));
    } else if (sort === 'quarter') {
      query = order === 'asc' ? query.orderBy(asc(quarterlyReports.quarter)) : query.orderBy(desc(quarterlyReports.quarter));
    } else if (sort === 'status') {
      query = order === 'asc' ? query.orderBy(asc(quarterlyReports.status)) : query.orderBy(desc(quarterlyReports.status));
    } else {
      query = order === 'asc' ? query.orderBy(asc(quarterlyReports.createdAt)) : query.orderBy(desc(quarterlyReports.createdAt));
    }

    const results = await query.limit(limit).offset(offset);

    return NextResponse.json(results);
  } catch (error) {
    console.error('GET error:', error);
    return NextResponse.json({ 
      error: 'Internal server error: ' + error 
    }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const requestBody = await request.json();
    
    if ('userId' in requestBody || 'user_id' in requestBody || 'authorId' in requestBody) {
      return NextResponse.json({ 
        error: "User ID cannot be provided in request body",
        code: "USER_ID_NOT_ALLOWED" 
      }, { status: 400 });
    }

    const { clientId, year, quarter, status, totalInvoices, totalAmount } = requestBody;

    if (!clientId || isNaN(parseInt(clientId))) {
      return NextResponse.json({ 
        error: "Valid client ID is required",
        code: "MISSING_CLIENT_ID" 
      }, { status: 400 });
    }

    if (!year || isNaN(parseInt(year))) {
      return NextResponse.json({ 
        error: "Valid year is required",
        code: "MISSING_YEAR" 
      }, { status: 400 });
    }

    if (!quarter || isNaN(parseInt(quarter)) || quarter < 1 || quarter > 4) {
      return NextResponse.json({ 
        error: "Valid quarter (1-4) is required",
        code: "INVALID_QUARTER" 
      }, { status: 400 });
    }

    const clientExists = await db.select()
      .from(clients)
      .where(eq(clients.id, parseInt(clientId)))
      .limit(1);

    if (clientExists.length === 0) {
      return NextResponse.json({ 
        error: "Client not found",
        code: "CLIENT_NOT_FOUND" 
      }, { status: 400 });
    }

    const insertData = {
      clientId: parseInt(clientId),
      year: parseInt(year),
      quarter: parseInt(quarter),
      status: status?.trim() || 'draft',
      totalInvoices: totalInvoices ? parseInt(totalInvoices) : 0,
      totalAmount: totalAmount ? parseFloat(totalAmount) : null,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    const newRecord = await db.insert(quarterlyReports)
      .values(insertData)
      .returning();

    return NextResponse.json(newRecord[0], { status: 201 });
  } catch (error) {
    console.error('POST error:', error);
    return NextResponse.json({ 
      error: 'Internal server error: ' + error 
    }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (!id || isNaN(parseInt(id))) {
      return NextResponse.json({ 
        error: "Valid ID is required",
        code: "INVALID_ID" 
      }, { status: 400 });
    }

    const requestBody = await request.json();
    
    if ('userId' in requestBody || 'user_id' in requestBody || 'authorId' in requestBody) {
      return NextResponse.json({ 
        error: "User ID cannot be provided in request body",
        code: "USER_ID_NOT_ALLOWED" 
      }, { status: 400 });
    }

    const existingRecord = await db.select()
      .from(quarterlyReports)
      .where(eq(quarterlyReports.id, parseInt(id)))
      .limit(1);

    if (existingRecord.length === 0) {
      return NextResponse.json({ error: 'Quarterly report not found' }, { status: 404 });
    }

    const { clientId, year, quarter, status, totalInvoices, totalAmount } = requestBody;
    const updates: any = {
      updatedAt: new Date().toISOString()
    };

    if (clientId !== undefined) {
      if (isNaN(parseInt(clientId))) {
        return NextResponse.json({ 
          error: "Valid client ID is required",
          code: "INVALID_CLIENT_ID" 
        }, { status: 400 });
      }

      const clientExists = await db.select()
        .from(clients)
        .where(eq(clients.id, parseInt(clientId)))
        .limit(1);

      if (clientExists.length === 0) {
        return NextResponse.json({ 
          error: "Client not found",
          code: "CLIENT_NOT_FOUND" 
        }, { status: 400 });
      }

      updates.clientId = parseInt(clientId);
    }

    if (year !== undefined) {
      if (isNaN(parseInt(year))) {
        return NextResponse.json({ 
          error: "Valid year is required",
          code: "INVALID_YEAR" 
        }, { status: 400 });
      }
      updates.year = parseInt(year);
    }

    if (quarter !== undefined) {
      if (isNaN(parseInt(quarter)) || quarter < 1 || quarter > 4) {
        return NextResponse.json({ 
          error: "Valid quarter (1-4) is required",
          code: "INVALID_QUARTER" 
        }, { status: 400 });
      }
      updates.quarter = parseInt(quarter);
    }

    if (status !== undefined) {
      updates.status = status.trim();
    }

    if (totalInvoices !== undefined) {
      updates.totalInvoices = parseInt(totalInvoices) || 0;
    }

    if (totalAmount !== undefined) {
      updates.totalAmount = totalAmount ? parseFloat(totalAmount) : null;
    }

    const updated = await db.update(quarterlyReports)
      .set(updates)
      .where(eq(quarterlyReports.id, parseInt(id)))
      .returning();

    return NextResponse.json(updated[0]);
  } catch (error) {
    console.error('PUT error:', error);
    return NextResponse.json({ 
      error: 'Internal server error: ' + error 
    }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (!id || isNaN(parseInt(id))) {
      return NextResponse.json({ 
        error: "Valid ID is required",
        code: "INVALID_ID" 
      }, { status: 400 });
    }

    const existingRecord = await db.select()
      .from(quarterlyReports)
      .where(eq(quarterlyReports.id, parseInt(id)))
      .limit(1);

    if (existingRecord.length === 0) {
      return NextResponse.json({ error: 'Quarterly report not found' }, { status: 404 });
    }

    const deleted = await db.delete(quarterlyReports)
      .where(eq(quarterlyReports.id, parseInt(id)))
      .returning();

    return NextResponse.json({ 
      message: 'Quarterly report deleted successfully',
      deletedRecord: deleted[0]
    });
  } catch (error) {
    console.error('DELETE error:', error);
    return NextResponse.json({ 
      error: 'Internal server error: ' + error 
    }, { status: 500 });
  }
}