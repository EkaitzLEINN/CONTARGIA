"use client";

import { useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Plus, Search, Loader2, Upload, Download, FileText, Trash2, Edit, CheckCircle, AlertCircle } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import * as XLSX from "xlsx";

interface Invoice {
  id: number;
  reportId: number;
  invoiceNumber: string;
  invoiceDate: string;
  supplierName: string;
  supplierRfc: string | null;
  subtotal: number;
  tax: number;
  total: number;
  concept: string | null;
  fileUrl: string | null;
  createdAt: string;
}

interface QuarterlyReport {
  id: number;
  clientId: number;
  year: number;
  quarter: number;
  status: string;
}

interface ClientOption {
  id: number;
  name: string;
}

export default function InvoicesPage() {
  const searchParams = useSearchParams();
  const reportIdParam = searchParams.get("reportId");
  
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [reports, setReports] = useState<QuarterlyReport[]>([]);
  const [clients, setClients] = useState<ClientOption[]>([]);
  const [selectedClientId, setSelectedClientId] = useState<string>("");
  const [selectedYear, setSelectedYear] = useState<string>(new Date().getFullYear().toString());
  const [selectedQuarter, setSelectedQuarter] = useState<string>("1");
  const [dragActive, setDragActive] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [ocrRows, setOcrRows] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingInvoice, setEditingInvoice] = useState<Invoice | null>(null);
  const [formData, setFormData] = useState({
    reportId: reportIdParam || "",
    invoiceNumber: "",
    invoiceDate: "",
    supplierName: "",
    supplierRfc: "",
    subtotal: "",
    tax: "",
    total: "",
    concept: "",
  });
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [exporting, setExporting] = useState(false);
  const [ocrMethod, setOcrMethod] = useState<'regex' | 'deepseek' | null>(null);

  useEffect(() => {
    fetchInvoices();
    fetchReports();
  }, [searchTerm]);

  // fetch clients for selector
  useEffect(() => {
    const fetchClients = async () => {
      try {
        const res = await fetch(`/api/clients?limit=200`);
        const data = await res.json();
        const opts = Array.isArray(data)
          ? data.map((c: any) => ({ id: c.id, name: `${c.name}` }))
          : [];
        setClients(opts);
      } catch (e) {
        setClients([]);
      }
    };
    fetchClients();
  }, []);

  // helper: create or get quarterly report id
  const createOrGetReport = async (): Promise<number | null> => {
    if (!selectedClientId || !selectedYear || !selectedQuarter) return null;
    const year = parseInt(selectedYear, 10);
    const quarter = parseInt(selectedQuarter, 10);

    // try to find existing
    const existing = reports.find(
      (r) => r.clientId === parseInt(selectedClientId, 10) && r.year === year && r.quarter === quarter
    );
    if (existing) return existing.id;

    // create
    const resp = await fetch("/api/quarterly-reports", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ clientId: parseInt(selectedClientId, 10), year, quarter, status: "draft" }),
    });
    if (!resp.ok) return null;
    const created = await resp.json();
    // refresh reports list
    fetchReports();
    return created?.id ?? null;
  };

  // process a single file via OCR API
  const processFile = async (file: File) => {
    const fd = new FormData();
    fd.append("file", file);
    const res = await fetch("/api/ocr", { method: "POST", body: fd });
    if (!res.ok) throw new Error("OCR falló");
    const json = await res.json();
    if (json.method) setOcrMethod(json.method);
    return json?.data;
  };

  const handleFiles = async (files: FileList | null) => {
    if (!files || files.length === 0) return;
    setUploading(true);
    try {
      const results: any[] = [];
      for (const file of Array.from(files)) {
        const data = await processFile(file);
        if (data) results.push({ ...data, __filename: file.name });
      }
      setOcrRows((prev) => [...prev, ...results]);
    } catch (e) {
      console.error(e);
    } finally {
      setUploading(false);
    }
  };

  const onDrop = async (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    await handleFiles(e.dataTransfer.files);
  };

  const onDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(true);
  };

  const onDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
  };

  const onFileInput = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const input = e.currentTarget;
    await handleFiles(e.target.files);
    // reset value to allow same file again
    if (input) {
      input.value = "";
    }
  };

  const saveParsedRows = async () => {
    const reportId = await createOrGetReport();
    if (!reportId) return;
    for (const row of ocrRows) {
      // fallback numbers
      const subtotal = typeof row.subtotal === "number" ? row.subtotal : 0;
      const tax = typeof row.tax === "number" ? row.tax : 0;
      const total = typeof row.total === "number" ? row.total : subtotal + tax;
      const payload = {
        reportId,
        invoiceNumber: row.invoiceNumber || row.__filename || "",
        invoiceDate: row.invoiceDate || new Date().toISOString().slice(0, 10),
        supplierName: row.supplierName || "",
        supplierRfc: row.supplierRfc || null,
        subtotal,
        tax,
        total,
        concept: row.concept || null,
      };
      await fetch("/api/invoices", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
    }
    // refresh
    setOcrRows([]);
    fetchInvoices();
  };

  const fetchInvoices = async () => {
    try {
      const response = await fetch(`/api/invoices?limit=100&search=${searchTerm}`);
      const data = await response.json();
      setInvoices(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error("Error fetching invoices:", error);
      setInvoices([]);
    } finally {
      setLoading(false);
    }
  };

  const fetchReports = async () => {
    try {
      const response = await fetch("/api/quarterly-reports?limit=100");
      const data = await response.json();
      setReports(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error("Error fetching reports:", error);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setSubmitting(true);

    try {
      const url = editingInvoice
        ? `/api/invoices?id=${editingInvoice.id}`
        : "/api/invoices";
      const method = editingInvoice ? "PUT" : "POST";

      const response = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          reportId: parseInt(formData.reportId),
          invoiceNumber: formData.invoiceNumber,
          invoiceDate: formData.invoiceDate,
          supplierName: formData.supplierName,
          supplierRfc: formData.supplierRfc || null,
          subtotal: parseFloat(formData.subtotal),
          tax: parseFloat(formData.tax),
          total: parseFloat(formData.total),
          concept: formData.concept || null,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "Error al guardar la factura");
      }

      setDialogOpen(false);
      setEditingInvoice(null);
      setFormData({
        reportId: reportIdParam || "",
        invoiceNumber: "",
        invoiceDate: "",
        supplierName: "",
        supplierRfc: "",
        subtotal: "",
        tax: "",
        total: "",
        concept: "",
      });
      fetchInvoices();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  const handleEdit = (invoice: Invoice) => {
    setEditingInvoice(invoice);
    setFormData({
      reportId: invoice.reportId.toString(),
      invoiceNumber: invoice.invoiceNumber,
      invoiceDate: invoice.invoiceDate,
      supplierName: invoice.supplierName,
      supplierRfc: invoice.supplierRfc || "",
      subtotal: invoice.subtotal.toString(),
      tax: invoice.tax.toString(),
      total: invoice.total.toString(),
      concept: invoice.concept || "",
    });
    setDialogOpen(true);
  };

  const handleDelete = async (id: number) => {
    if (!confirm("¿Estás seguro de eliminar esta factura?")) return;

    try {
      await fetch(`/api/invoices?id=${id}`, { method: "DELETE" });
      fetchInvoices();
    } catch (error) {
      console.error("Error deleting invoice:", error);
    }
  };

  const handleDialogClose = () => {
    setDialogOpen(false);
    setEditingInvoice(null);
    setFormData({
      reportId: reportIdParam || "",
      invoiceNumber: "",
      invoiceDate: "",
      supplierName: "",
      supplierRfc: "",
      subtotal: "",
      tax: "",
      total: "",
      concept: "",
    });
    setError("");
  };

  const handleExportToExcel = () => {
    setExporting(true);
    
    try {
      const exportData = invoices.map((invoice) => ({
        "No. Factura": invoice.invoiceNumber,
        "Fecha": new Date(invoice.invoiceDate).toLocaleDateString("es-ES"),
        "Proveedor": invoice.supplierName,
        "NIF Proveedor": invoice.supplierRfc || "N/A",
        "Subtotal": invoice.subtotal,
        "IVA": invoice.tax,
        "Total": invoice.total,
        "Concepto": invoice.concept || "N/A",
      }));

      const ws = XLSX.utils.json_to_sheet(exportData);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, "Facturas");

      // Auto-size columns
      const maxWidth = exportData.reduce((w, r) => Math.max(w, r["Proveedor"].length), 10);
      ws["!cols"] = [
        { wch: 15 }, // No. Factura
        { wch: 12 }, // Fecha
        { wch: maxWidth }, // Proveedor
        { wch: 15 }, // NIF
        { wch: 12 }, // Subtotal
        { wch: 12 }, // IVA
        { wch: 12 }, // Total
        { wch: 30 }, // Concepto
      ];

      const fileName = `facturas_${new Date().toISOString().split("T")[0]}.xlsx`;
      XLSX.writeFile(wb, fileName);
    } catch (error) {
      console.error("Error exporting to Excel:", error);
      alert("Error al exportar a Excel");
    } finally {
      setExporting(false);
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("es-ES", {
      style: "currency",
      currency: "EUR",
    }).format(amount);
  };

  const getReportLabel = (reportId: number) => {
    const report = reports.find((r) => r.id === reportId);
    return report ? `Q${report.quarter} ${report.year}` : "N/A";
  };

  const calculateTotals = () => {
    const subtotal = invoices.reduce((sum, inv) => sum + inv.subtotal, 0);
    const tax = invoices.reduce((sum, inv) => sum + inv.tax, 0);
    const total = invoices.reduce((sum, inv) => sum + inv.total, 0);
    return { subtotal, tax, total };
  };

  const totals = calculateTotals();

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* New: Selectors + Dropzone */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg">Procesar facturas por OCR</CardTitle>
              {ocrMethod && (
                <Badge variant={ocrMethod === 'deepseek' ? 'default' : 'secondary'} className="gap-1">
                  {ocrMethod === 'deepseek' ? (
                    <>
                      <CheckCircle className="h-3 w-3" />
                      IA Mejorada
                    </>
                  ) : (
                    <>
                      <AlertCircle className="h-3 w-3" />
                      Extracción Básica
                    </>
                  )}
                </Badge>
              )}
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-4 md:grid-cols-3">
              <div className="grid gap-2">
                <Label>Cliente</Label>
                <Select value={selectedClientId} onValueChange={setSelectedClientId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecciona cliente" />
                  </SelectTrigger>
                  <SelectContent>
                    {clients.map((c) => (
                      <SelectItem key={c.id} value={c.id.toString()}>{c.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-2">
                <Label>Año</Label>
                <Select value={selectedYear} onValueChange={setSelectedYear}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecciona año" />
                  </SelectTrigger>
                  <SelectContent>
                    {Array.from({ length: 6 }).map((_, i) => {
                      const y = (new Date().getFullYear() - i).toString();
                      return (
                        <SelectItem key={y} value={y}>{y}</SelectItem>
                      );
                    })}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-2">
                <Label>Trimestre</Label>
                <Select value={selectedQuarter} onValueChange={setSelectedQuarter}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecciona trimestre" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">Q1</SelectItem>
                    <SelectItem value="2">Q2</SelectItem>
                    <SelectItem value="3">Q3</SelectItem>
                    <SelectItem value="4">Q4</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div
              onDrop={onDrop}
              onDragOver={onDragOver}
              onDragLeave={onDragLeave}
              className={`border-2 border-dashed rounded-md p-8 text-center transition ${dragActive ? "border-primary bg-primary/5" : "border-muted"}`}
            >
              <div className="flex flex-col items-center gap-2">
                <Upload className="h-6 w-6 text-muted-foreground" />
                <p className="text-sm text-muted-foreground">
                  Arrastra y suelta PDFs aquí o
                  <label className="text-primary hover:underline cursor-pointer ml-1">
                    selecciona archivos
                    <input type="file" accept="application/pdf" multiple className="hidden" onChange={onFileInput} />
                  </label>
                </p>
                {uploading && (
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Loader2 className="h-4 w-4 animate-spin" /> Procesando con IA...
                  </div>
                )}
              </div>
            </div>

            {ocrRows.length > 0 && (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="font-medium">Vista previa ({ocrRows.length})</h4>
                  <Button size="sm" onClick={saveParsedRows} disabled={!selectedClientId || uploading}>
                    Guardar en reporte
                  </Button>
                </div>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Archivo</TableHead>
                        <TableHead>No. Factura</TableHead>
                        <TableHead>Fecha</TableHead>
                        <TableHead>Proveedor</TableHead>
                        <TableHead>NIF/CIF</TableHead>
                        <TableHead className="text-right">Subtotal</TableHead>
                        <TableHead className="text-right">IVA</TableHead>
                        <TableHead className="text-right">Total</TableHead>
                        <TableHead>Resumen</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {ocrRows.map((r, idx) => (
                        <TableRow key={idx}>
                          <TableCell className="text-muted-foreground text-sm">{r.__filename || "-"}</TableCell>
                          <TableCell className="font-mono text-sm">{r.invoiceNumber || "-"}</TableCell>
                          <TableCell className="text-sm">{r.invoiceDate || "-"}</TableCell>
                          <TableCell className="font-medium">{r.supplierName || "-"}</TableCell>
                          <TableCell>
                            {r.supplierRfc ? (
                              <Badge variant="outline" className="font-mono text-xs">{r.supplierRfc}</Badge>
                            ) : (
                              <span className="text-muted-foreground text-sm">-</span>
                            )}
                          </TableCell>
                          <TableCell className="text-right">{r.subtotal ?? "-"}</TableCell>
                          <TableCell className="text-right">{r.tax ?? "-"}</TableCell>
                          <TableCell className="text-right font-medium">{r.total ?? "-"}</TableCell>
                          <TableCell className="max-w-xs">
                            {r.summary ? (
                              <p className="text-xs text-muted-foreground line-clamp-2">{r.summary}</p>
                            ) : (
                              <span className="text-muted-foreground text-sm">-</span>
                            )}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Summary Cards */}
        <div className="grid gap-4 md:grid-cols-3">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Subtotal
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{formatCurrency(totals.subtotal)}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                IVA Total
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{formatCurrency(totals.tax)}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Total General
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-primary">
                {formatCurrency(totals.total)}
              </div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <div className="flex items-center gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Buscar por número de factura, proveedor o concepto..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="flex items-center justify-center py-12">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : invoices.length === 0 ? (
              <div className="text-center py-12 text-muted-foreground">
                {searchTerm
                  ? "No se encontraron facturas"
                  : "No hay facturas registradas. Crea una para comenzar."}
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>No. Factura</TableHead>
                      <TableHead>Fecha</TableHead>
                      <TableHead>Proveedor</TableHead>
                      <TableHead>NIF/CIF</TableHead>
                      <TableHead className="text-right">Subtotal</TableHead>
                      <TableHead className="text-right">IVA</TableHead>
                      <TableHead className="text-right">Total</TableHead>
                      <TableHead>Periodo</TableHead>
                      <TableHead className="text-right">Acciones</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {invoices.map((invoice) => (
                      <TableRow key={invoice.id}>
                        <TableCell className="font-medium font-mono text-sm">
                          {invoice.invoiceNumber}
                        </TableCell>
                        <TableCell className="text-sm">
                          {new Date(invoice.invoiceDate).toLocaleDateString("es-ES")}
                        </TableCell>
                        <TableCell>{invoice.supplierName}</TableCell>
                        <TableCell>
                          {invoice.supplierRfc ? (
                            <Badge variant="outline" className="font-mono text-xs">{invoice.supplierRfc}</Badge>
                          ) : (
                            <span className="text-muted-foreground text-sm">N/A</span>
                          )}
                        </TableCell>
                        <TableCell className="text-right">
                          {formatCurrency(invoice.subtotal)}
                        </TableCell>
                        <TableCell className="text-right">
                          {formatCurrency(invoice.tax)}
                        </TableCell>
                        <TableCell className="text-right font-medium">
                          {formatCurrency(invoice.total)}
                        </TableCell>
                        <TableCell>
                          <Badge variant="secondary">
                            {getReportLabel(invoice.reportId)}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleEdit(invoice)}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleDelete(invoice.id)}
                            >
                              <Trash2 className="h-4 w-4 text-destructive" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}