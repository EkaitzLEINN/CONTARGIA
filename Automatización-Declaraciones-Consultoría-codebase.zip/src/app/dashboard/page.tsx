"use client";

import { useEffect, useState } from "react";
import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, FileBarChart, FileText, TrendingUp, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { useSession } from "@/lib/auth-client";

interface Stats {
  totalClients: number;
  totalReports: number;
  totalInvoices: number;
  processingReports: number;
}

export default function DashboardPage() {
  const { data: session } = useSession();
  const [stats, setStats] = useState<Stats>({
    totalClients: 0,
    totalReports: 0,
    totalInvoices: 0,
    processingReports: 0,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const [clientsRes, reportsRes, invoicesRes] = await Promise.all([
          fetch("/api/clients?limit=1"),
          fetch("/api/quarterly-reports?limit=100"),
          fetch("/api/invoices?limit=1"),
        ]);

        const clients = await clientsRes.json();
        const reports = await reportsRes.json();
        const invoices = await invoicesRes.json();

        const processingCount = Array.isArray(reports) 
          ? reports.filter((r: any) => r.status === "processing").length 
          : 0;

        setStats({
          totalClients: Array.isArray(clients) ? clients.length : 0,
          totalReports: Array.isArray(reports) ? reports.length : 0,
          totalInvoices: Array.isArray(invoices) ? invoices.length : 0,
          processingReports: processingCount,
        });
      } catch (error) {
        console.error("Error fetching stats:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchStats();
  }, []);

  const statCards = [
    {
      title: "Total Clientes",
      value: stats.totalClients,
      icon: Users,
      color: "text-blue-600",
      bgColor: "bg-blue-50 dark:bg-blue-950",
    },
    {
      title: "Reportes Trimestrales",
      value: stats.totalReports,
      icon: FileBarChart,
      color: "text-green-600",
      bgColor: "bg-green-50 dark:bg-green-950",
    },
    {
      title: "Facturas Procesadas",
      value: stats.totalInvoices,
      icon: FileText,
      color: "text-purple-600",
      bgColor: "bg-purple-50 dark:bg-purple-950",
    },
    {
      title: "En Procesamiento",
      value: stats.processingReports,
      icon: TrendingUp,
      color: "text-orange-600",
      bgColor: "bg-orange-50 dark:bg-orange-950",
    },
  ];

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">
            Bienvenido, {session?.user?.name || "Usuario"}
          </h1>
          <p className="text-muted-foreground mt-1">
            Panel de control de declaraciones trimestrales
          </p>
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : (
          <>
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
              {statCards.map((stat) => {
                const Icon = stat.icon;
                return (
                  <Card key={stat.title}>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">
                        {stat.title}
                      </CardTitle>
                      <div className={`${stat.bgColor} p-2 rounded-lg`}>
                        <Icon className={`h-4 w-4 ${stat.color}`} />
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">{stat.value}</div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>

            <div className="grid gap-6 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>Acciones Rápidas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Link href="/clients">
                    <Button variant="outline" className="w-full justify-start">
                      <Users className="mr-2 h-4 w-4" />
                      Gestionar Clientes
                    </Button>
                  </Link>
                  <Link href="/reports">
                    <Button variant="outline" className="w-full justify-start">
                      <FileBarChart className="mr-2 h-4 w-4" />
                      Ver Reportes Trimestrales
                    </Button>
                  </Link>
                  <Link href="/invoices">
                    <Button variant="outline" className="w-full justify-start">
                      <FileText className="mr-2 h-4 w-4" />
                      Gestionar Facturas
                    </Button>
                  </Link>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Información del Sistema</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Estado del Sistema</span>
                    <span className="text-sm font-medium text-green-600">Operativo</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Última Actualización</span>
                    <span className="text-sm font-medium">
                      {new Date().toLocaleDateString("es-MX")}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Versión</span>
                    <span className="text-sm font-medium">1.0.0</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </>
        )}
      </div>
    </DashboardLayout>
  );
}