"use client";

import { useEffect, useState } from "react";
import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Plus, Search, Edit, Trash2, Loader2, Mail, Phone, MapPin } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface Client {
  id: number;
  name: string;
  nif: string;
  email: string | null;
  phone: string | null;
  address: string | null;
  createdAt: string;
  updatedAt: string;
}

export default function ClientsPage() {
  const [clients, setClients] = useState<Client[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingClient, setEditingClient] = useState<Client | null>(null);
  const [formData, setFormData] = useState({
    name: "",
    nif: "",
    email: "",
    phone: "",
    address: "",
  });
  const [idType, setIdType] = useState<"NIF_NIE" | "CIF">("NIF_NIE");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [nifTouched, setNifTouched] = useState(false);

  // Simple DNI/NIE validation + CIF support
  const dniNieRegex = /^([XYZ]?)(\d{7,8})([A-Z])$/i;
  const computeDniLetter = (num: number) => "TRWAGMYFPDXBNJZSQVHLCKE"[num % 23];

  const isValidDniNie = (value: string) => {
    const m = value.match(dniNieRegex);
    if (!m) return false;
    let [, prefix, digits, letter] = m;
    let number = parseInt(digits, 10);
    if (prefix) {
      const map: Record<string, number> = { X: 0, Y: 1, Z: 2 };
      number = parseInt(`${map[prefix.toUpperCase()]}${digits}`, 10);
    }
    const expected = computeDniLetter(number);
    return expected === letter.toUpperCase();
  };

  // CIF validation - SIMPLIFIED: just check format (letter + 7 digits + control)
  // No checksum validation to avoid false rejections
  const isValidCif = (value: string) => {
    // CIF format: Letter [ABCDEFGHJKLMNPQRSUVW] + 7 digits + control (0-9 or A-J)
    return /^[ABCDEFGHJKLMNPQRSUVW]\d{7}[0-9A-J]$/i.test(value);
  };

  const isValidSpanishId = (() => {
    const value = formData.nif.trim().toUpperCase();
    if (!value) return false;
    return isValidDniNie(value) || isValidCif(value);
  })();

  const fetchClients = async () => {
    try {
      const response = await fetch(`/api/clients?limit=100&search=${searchTerm}`);
      const data = await response.json();
      setClients(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error("Error fetching clients:", error);
      setClients([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchClients();
  }, [searchTerm]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setSubmitting(true);

    if (!isValidSpanishId) {
      setError("NIF/NIE/CIF inválido. Revisa el formato y la letra de control.");
      setSubmitting(false);
      return;
    }

    try {
      const url = editingClient
        ? `/api/clients?id=${editingClient.id}`
        : "/api/clients";
      const method = editingClient ? "PUT" : "POST";

      const response = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...formData }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "Error al guardar el cliente");
      }

      setDialogOpen(false);
      setEditingClient(null);
      setFormData({ name: "", nif: "", email: "", phone: "", address: "" });
      setIdType("NIF_NIE");
      fetchClients();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  const handleEdit = (client: Client) => {
    setEditingClient(client);
    setFormData({
      name: client.name,
      nif: client.nif,
      email: client.email || "",
      phone: client.phone || "",
      address: client.address || "",
    });
    // heuristic: if starts with A-HJ... and matches CIF length, preselect CIF
    const v = (client.nif || "").toUpperCase();
    setIdType(/^[ABCDEFGHJKLMNPQRSUVW]/.test(v) ? "CIF" : "NIF_NIE");
    setDialogOpen(true);
  };

  const handleDelete = async (id: number) => {
    if (!confirm("¿Estás seguro de eliminar este cliente?")) return;

    try {
      await fetch(`/api/clients?id=${id}`, { method: "DELETE" });
      fetchClients();
    } catch (error) {
      console.error("Error deleting client:", error);
    }
  };

  const handleDialogClose = () => {
    setDialogOpen(false);
    setEditingClient(null);
    setFormData({ name: "", nif: "", email: "", phone: "", address: "" });
    setError("");
    setNifTouched(false);
    setIdType("NIF_NIE");
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Clientes</h1>
            <p className="text-muted-foreground mt-1">
              Gestiona la información fiscal de tus clientes
            </p>
          </div>
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button onClick={() => handleDialogClose()}>
                <Plus className="mr-2 h-4 w-4" />
                Nuevo Cliente
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[520px]">
              <form onSubmit={handleSubmit}>
                <DialogHeader>
                  <DialogTitle>
                    {editingClient ? "Editar Cliente" : "Nuevo Cliente"}
                  </DialogTitle>
                  <DialogDescription>
                    {editingClient
                      ? "Actualiza la información del cliente"
                      : "Completa los datos fiscales del nuevo cliente"}
                  </DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  {error && (
                    <Alert variant="destructive">
                      <AlertDescription>{error}</AlertDescription>
                    </Alert>
                  )}
                  <div className="grid gap-2">
                    <Label htmlFor="name">Nombre o Razón Social *</Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) =>
                        setFormData({ ...formData, name: e.target.value })
                      }
                      required
                      disabled={submitting}
                      placeholder="Nombre del cliente o empresa"
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="nif">NIF/NIE/CIF *</Label>
                    <Input
                      id="nif"
                      value={formData.nif}
                      onChange={(e) => {
                        setFormData({ ...formData, nif: e.target.value.toUpperCase() });
                        if (!nifTouched) setNifTouched(true);
                      }}
                      onBlur={() => setNifTouched(true)}
                      required
                      disabled={submitting}
                      placeholder="12345678Z, X1234567L o G56593783"
                      maxLength={9}
                    />
                    <p className={`text-xs ${nifTouched && !isValidSpanishId ? "text-destructive" : "text-muted-foreground"}`}>
                      {nifTouched && !isValidSpanishId
                        ? "NIF/NIE/CIF inválido. Revisa el formato y la letra de control."
                        : "NIF: 8 dígitos + letra | NIE: letra + 7 dígitos + letra | CIF: letra + 7 dígitos + control"}
                    </p>
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="email">Correo Electrónico</Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) =>
                        setFormData({ ...formData, email: e.target.value })
                      }
                      disabled={submitting}
                      placeholder="cliente@ejemplo.es"
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="phone">Teléfono</Label>
                    <Input
                      id="phone"
                      value={formData.phone}
                      onChange={(e) =>
                        setFormData({ ...formData, phone: e.target.value })
                      }
                      disabled={submitting}
                      placeholder="+34 600 000 000"
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="address">Dirección Fiscal</Label>
                    <Input
                      id="address"
                      value={formData.address}
                      onChange={(e) =>
                        setFormData({ ...formData, address: e.target.value })
                      }
                      disabled={submitting}
                      placeholder="Calle, número, ciudad, código postal"
                    />
                  </div>
                </div>
                <DialogFooter>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={handleDialogClose}
                    disabled={submitting}
                  >
                    Cancelar
                  </Button>
                  <Button type="submit" disabled={submitting || (nifTouched && !isValidSpanishId)}>
                    {submitting ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Guardando...
                      </>
                    ) : (
                      "Guardar"
                    )}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        <Card>
          <CardHeader>
            <div className="flex items-center gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Buscar por nombre, NIF/NIE/CIF o email..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="flex items-center justify-center py-12">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : clients.length === 0 ? (
              <div className="text-center py-12 text-muted-foreground">
                {searchTerm
                  ? "No se encontraron clientes"
                  : "No hay clientes registrados. Crea uno para comenzar."}
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Nombre</TableHead>
                    <TableHead>NIF/NIE/CIF</TableHead>
                    <TableHead>Contacto</TableHead>
                    <TableHead className="text-right">Acciones</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {clients.map((client) => (
                    <TableRow key={client.id}>
                      <TableCell className="font-medium">{client.name}</TableCell>
                      <TableCell>
                        <Badge variant="secondary">{client.nif}</Badge>
                      </TableCell>
                      <TableCell>
                        <div className="space-y-1 text-sm">
                          {client.email && (
                            <div className="flex items-center gap-1 text-muted-foreground">
                              <Mail className="h-3 w-3" />
                              {client.email}
                            </div>
                          )}
                          {client.phone && (
                            <div className="flex items-center gap-1 text-muted-foreground">
                              <Phone className="h-3 w-3" />
                              {client.phone}
                            </div>
                          )}
                        </div>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleEdit(client)}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleDelete(client.id)}
                          >
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}