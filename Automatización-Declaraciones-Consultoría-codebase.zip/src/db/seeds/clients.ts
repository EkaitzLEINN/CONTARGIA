import { db } from '@/db';
import { clients } from '@/db/schema';

async function main() {
    const sampleClients = [
        {
            name: 'Tecnología Avanzada SA de CV',
            rfc: 'TEC950101ABC',
            email: 'contacto@tecavanzada.com.mx',
            phone: '5512345678',
            address: 'Av. Insurgentes Sur 1234, Col. Del Valle, 03100 Ciudad de México, CDMX',
            createdAt: new Date('2024-01-15').toISOString(),
            updatedAt: new Date('2024-01-15').toISOString(),
        },
        {
            name: 'Construcciones del Norte SA',
            rfc: 'CON940215XY1',
            email: 'ventas@connorte.com.mx',
            phone: '8187654321',
            address: 'Blvd. Díaz Ordaz 567, Col. San Pedro, 66220 San Pedro Garza García, NL',
            createdAt: new Date('2024-01-20').toISOString(),
            updatedAt: new Date('2024-01-20').toISOString(),
        },
        {
            name: 'Comercializadora Azteca',
            rfc: 'COM851022DEF',
            email: 'info@comercializadoraazteca.com',
            phone: '3398765432',
            address: 'Av. López Mateos Sur 890, Col. Chapalita, 45040 Zapopan, Jalisco',
            createdAt: new Date('2024-02-01').toISOString(),
            updatedAt: new Date('2024-02-01').toISOString(),
        },
        {
            name: 'Servicios Integrales del Bajío',
            rfc: 'SIB920308GHI',
            email: 'servicios@sibajio.outlook.com',
            phone: '4421234567',
            address: 'Av. Constituyentes 1456, Col. El Jacal, 76170 Santiago de Querétaro, Qro',
            createdAt: new Date('2024-02-10').toISOString(),
            updatedAt: new Date('2024-02-10').toISOString(),
        },
        {
            name: 'Manufacturas de Guadalajara',
            rfc: 'MAN880712JKL',
            email: 'gerencia@manguadalajara.gmail.com',
            phone: '2221567890',
            address: 'Calz. Zavaleta 2345, Col. La Paz, 72160 Puebla, Puebla',
            createdAt: new Date('2024-02-15').toISOString(),
            updatedAt: new Date('2024-02-15').toISOString(),
        },
    ];

    await db.insert(clients).values(sampleClients);
    
    console.log('✅ Clients seeder completed successfully');
}

main().catch((error) => {
    console.error('❌ Seeder failed:', error);
});