import { db } from '@/db';
import { quarterlyReports } from '@/db/schema';

async function main() {
    const sampleQuarterlyReports = [
        {
            clientId: 1,
            year: 2024,
            quarter: 1,
            status: 'completed',
            totalInvoices: 8,
            totalAmount: 125000.50,
            createdAt: new Date('2024-04-01T10:00:00.000Z').toISOString(),
            updatedAt: new Date('2024-04-15T14:30:00.000Z').toISOString(),
        },
        {
            clientId: 1,
            year: 2024,
            quarter: 2,
            status: 'processing',
            totalInvoices: 6,
            totalAmount: 89500.25,
            createdAt: new Date('2024-07-01T09:15:00.000Z').toISOString(),
            updatedAt: new Date('2024-07-20T16:45:00.000Z').toISOString(),
        },
        {
            clientId: 2,
            year: 2024,
            quarter: 3,
            status: 'draft',
            totalInvoices: 0,
            totalAmount: 0,
            createdAt: new Date('2024-10-01T08:30:00.000Z').toISOString(),
            updatedAt: new Date('2024-10-01T08:30:00.000Z').toISOString(),
        }
    ];

    await db.insert(quarterlyReports).values(sampleQuarterlyReports);
    
    console.log('✅ Quarterly reports seeder completed successfully');
}

main().catch((error) => {
    console.error('❌ Seeder failed:', error);
});