# 📊 App de Automatización de Declaraciones Trimestrales

Sistema completo de automatización de declaraciones trimestrales diseñado específicamente para consultorías fiscales en México.

## 🚀 Características Principales

### 1. **Sistema de Autenticación**
- Registro de usuarios con validación
- Inicio de sesión seguro
- Gestión de sesiones con JWT
- Protección de rutas mediante middleware

### 2. **Gestión de Clientes**
- ✅ Crear, editar y eliminar clientes
- ✅ Almacenar información completa: nombre, RFC, email, teléfono, dirección
- ✅ Validación de RFC único
- ✅ Búsqueda en tiempo real
- ✅ Interfaz con tabla responsiva

### 3. **Reportes Trimestrales**
- ✅ Crear reportes por cliente y periodo (Q1-Q4)
- ✅ Gestión de estados: Borrador, En Proceso, Completado
- ✅ Seguimiento de facturas y montos totales
- ✅ Visualización por año y trimestre
- ✅ Filtros avanzados

### 4. **Gestión de Facturas**
- ✅ Registro completo de facturas con todos los campos fiscales
- ✅ Número de factura, fecha, proveedor, RFC
- ✅ Cálculo automático de subtotal, IVA y total
- ✅ Asociación a reportes trimestrales
- ✅ Búsqueda por múltiples criterios
- ✅ Edición y eliminación de facturas

### 5. **Exportación a Excel**
- ✅ Exportación de facturas a formato XLSX
- ✅ Columnas auto-ajustadas
- ✅ Formato profesional listo para análisis
- ✅ Generación instantánea con un clic

### 6. **Dashboard Interactivo**
- ✅ Estadísticas en tiempo real
- ✅ Totales de clientes, reportes y facturas
- ✅ Accesos rápidos a funciones principales
- ✅ Diseño responsivo y moderno

## 📁 Estructura del Proyecto

```
src/
├── app/
│   ├── api/
│   │   ├── auth/[...all]/         # Endpoints de autenticación
│   │   ├── clients/               # API de clientes
│   │   ├── quarterly-reports/     # API de reportes trimestrales
│   │   └── invoices/              # API de facturas
│   ├── sign-in/                   # Página de inicio de sesión
│   ├── sign-up/                   # Página de registro
│   ├── dashboard/                 # Dashboard principal
│   ├── clients/                   # Gestión de clientes
│   ├── reports/                   # Reportes trimestrales
│   ├── invoices/                  # Gestión de facturas
│   └── page.tsx                   # Landing page
├── components/
│   ├── DashboardLayout.tsx        # Layout con sidebar
│   └── ui/                        # Componentes de Shadcn/UI
├── db/
│   ├── schema.ts                  # Esquema de base de datos
│   ├── index.ts                   # Cliente de base de datos
│   └── seeds/                     # Datos de prueba
└── lib/
    ├── auth.ts                    # Configuración de autenticación
    └── auth-client.ts             # Cliente de autenticación
```

## 🗄️ Base de Datos

### Tablas Principales:

**1. clients** - Información de clientes
- id, name, rfc (único), email, phone, address
- Timestamps de creación y actualización

**2. quarterly_reports** - Reportes trimestrales
- id, clientId, year, quarter (1-4), status
- totalInvoices, totalAmount
- Timestamps de creación y actualización

**3. invoices** - Facturas
- id, reportId, invoiceNumber, invoiceDate
- supplierName, supplierRfc
- subtotal, tax, total, concept, fileUrl
- Timestamp de creación

**4. Auth Tables** - Sistema de autenticación
- user, session, account, verification

## 🔐 API Endpoints

### Clientes (`/api/clients`)
- `GET /api/clients` - Listar todos los clientes (con paginación y búsqueda)
- `GET /api/clients?id=[id]` - Obtener cliente por ID
- `POST /api/clients` - Crear nuevo cliente
- `PUT /api/clients?id=[id]` - Actualizar cliente
- `DELETE /api/clients?id=[id]` - Eliminar cliente

### Reportes Trimestrales (`/api/quarterly-reports`)
- `GET /api/quarterly-reports` - Listar reportes (con filtros)
- `GET /api/quarterly-reports?id=[id]` - Obtener reporte por ID
- `POST /api/quarterly-reports` - Crear nuevo reporte
- `PUT /api/quarterly-reports?id=[id]` - Actualizar reporte
- `DELETE /api/quarterly-reports?id=[id]` - Eliminar reporte

### Facturas (`/api/invoices`)
- `GET /api/invoices` - Listar facturas (con búsqueda)
- `GET /api/invoices?id=[id]` - Obtener factura por ID
- `POST /api/invoices` - Crear nueva factura
- `PUT /api/invoices?id=[id]` - Actualizar factura
- `DELETE /api/invoices?id=[id]` - Eliminar factura

## 🎯 Flujo de Trabajo

1. **Registro e Inicio de Sesión**
   - Crear cuenta o iniciar sesión
   - Redirección automática al dashboard

2. **Crear Cliente**
   - Ir a "Clientes"
   - Click en "Nuevo Cliente"
   - Completar información (RFC es único)
   - Guardar

3. **Crear Reporte Trimestral**
   - Ir a "Reportes Trimestrales"
   - Click en "Nuevo Reporte"
   - Seleccionar cliente, año y trimestre
   - Crear reporte

4. **Registrar Facturas**
   - Ir a "Facturas"
   - Click en "Nueva Factura"
   - Seleccionar reporte trimestral
   - Completar datos de la factura
   - Guardar

5. **Exportar a Excel**
   - En la página de facturas
   - Click en "Exportar a Excel"
   - Archivo descargado automáticamente

## 🎨 Tecnologías Utilizadas

- **Framework**: Next.js 15 con App Router
- **Autenticación**: Better-Auth con JWT
- **Base de Datos**: Turso (LibSQL)
- **ORM**: Drizzle ORM
- **UI**: Shadcn/UI + Tailwind CSS
- **Iconos**: Lucide React
- **Excel Export**: XLSX
- **TypeScript**: Tipado completo

## 🔒 Seguridad

- ✅ Autenticación obligatoria para todas las páginas protegidas
- ✅ Middleware para validación de sesiones
- ✅ Tokens JWT seguros
- ✅ Validación de datos en servidor y cliente
- ✅ Sanitización de entradas
- ✅ Prevención de inyección SQL con ORM

## 🌐 Rutas Protegidas

Las siguientes rutas requieren autenticación:
- `/dashboard` - Dashboard principal
- `/clients` - Gestión de clientes
- `/reports` - Reportes trimestrales
- `/invoices` - Gestión de facturas

## 📱 Responsive Design

- ✅ Diseño adaptable a móviles, tablets y desktop
- ✅ Sidebar colapsable en móviles
- ✅ Tablas con scroll horizontal
- ✅ Menú de navegación optimizado

## 🎯 Próximas Funcionalidades (Opcionales)

- 📤 Carga masiva de facturas desde PDF (OCR)
- 📊 Gráficas y estadísticas avanzadas
- 📧 Notificaciones por email
- 🔄 Sincronización con SAT
- 📱 App móvil nativa
- 🤖 Asistente IA para clasificación de facturas

## 🚦 Cómo Usar

1. **Registrarse**: Ir a la página principal y hacer clic en "Registrarse"
2. **Crear un cliente**: Agregar información de RFC, nombre y contacto
3. **Crear reporte trimestral**: Seleccionar cliente y periodo
4. **Agregar facturas**: Registrar todas las facturas del periodo
5. **Exportar**: Descargar reporte en Excel para análisis

## 💡 Notas Importantes

- **RFC**: Debe ser único en el sistema
- **Trimestres**: Q1 (Ene-Mar), Q2 (Abr-Jun), Q3 (Jul-Sep), Q4 (Oct-Dic)
- **Estados de Reportes**: 
  - Borrador: Reporte en creación
  - En Proceso: Facturas siendo cargadas
  - Completado: Reporte listo para declaración
- **Montos**: Formato mexicano con IVA del 16%

## 🎉 ¡Listo para Usar!

El sistema está completamente funcional y listo para automatizar tus declaraciones trimestrales. Todas las operaciones CRUD funcionan correctamente y la exportación a Excel está implementada.

---

**Desarrollado con ❤️ para consultorías fiscales en México**