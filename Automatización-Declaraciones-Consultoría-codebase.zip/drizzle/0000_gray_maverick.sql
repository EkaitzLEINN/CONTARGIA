CREATE TABLE `clients` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`name` text NOT NULL,
	`rfc` text NOT NULL,
	`email` text,
	`phone` text,
	`address` text,
	`created_at` text NOT NULL,
	`updated_at` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `clients_rfc_unique` ON `clients` (`rfc`);--> statement-breakpoint
CREATE TABLE `invoices` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`report_id` integer,
	`invoice_number` text NOT NULL,
	`invoice_date` text NOT NULL,
	`supplier_name` text NOT NULL,
	`supplier_rfc` text,
	`subtotal` real NOT NULL,
	`tax` real NOT NULL,
	`total` real NOT NULL,
	`concept` text,
	`file_url` text,
	`created_at` text NOT NULL,
	FOREIGN KEY (`report_id`) REFERENCES `quarterly_reports`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE TABLE `quarterly_reports` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`client_id` integer,
	`year` integer NOT NULL,
	`quarter` integer NOT NULL,
	`status` text DEFAULT 'draft' NOT NULL,
	`total_invoices` integer DEFAULT 0,
	`total_amount` real,
	`created_at` text NOT NULL,
	`updated_at` text NOT NULL,
	FOREIGN KEY (`client_id`) REFERENCES `clients`(`id`) ON UPDATE no action ON DELETE no action
);
